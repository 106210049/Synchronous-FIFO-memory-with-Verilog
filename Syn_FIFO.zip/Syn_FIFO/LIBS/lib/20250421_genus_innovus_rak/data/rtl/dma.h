`define DMA_IDLE         4'b0000
`define DMA_DFLAG        4'b0001
`define DMA_BGRANT       4'b0010
`define DMA_WRITE1       4'b0011
`define DMA_WRITE2       4'b0100
`define DMA_WRITE_CLEAR  4'b0101
`define DMA_CLEAR 		 4'b0110
`define DMA_ADD_INCR     4'b0111
`define DMA_TOP_BUF_FLAG 4'b1000

